	 <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                    

<?php echo form_open_multipart('admin/index'); ?>
			<span class="msg">	
     <?php echo $this->session->flashdata('msg');?>			
				</span>
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="E-mail" name="email" type="text"  >
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" >
                                </div>
                               <!-- <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>-->
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
				<input type="submit" class="btn btn-lg btn-success btn-block" name="submit" value="Login" />
                                
                            </fieldset>
                        </form>
                    </div>
                </div>

