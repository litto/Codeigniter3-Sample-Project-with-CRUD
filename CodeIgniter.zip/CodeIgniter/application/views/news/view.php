
  <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                   
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
               <?php echo $title; ?>
                        </div>
            <span class="msg">              

                </span>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">


                                 <input type="hidden" name="newsid" value="<?php echo $news_item['id']; ?>"/>
                                        <div class="form-group">
                                            <label>Title</label>
                                           <?php echo $news_item['title']; ?>
                                        
                                        </div>
                                            <div class="form-group">
                                            <label>Text</label>
                                    
                                              <?php echo $news_item['text']; ?>
                                        </div>
                                                  <div class="form-group">
                                            <label>Photo</label><image  height="100px" width="100px" src="<?php echo base_url('uploads/'. $news_item['image']);?>"/>
                                     
                                            
                                        </div>
                                              
                    <div class="form-group">
                                            <label></label>
                                            <a href="<?php echo site_url('news/index/');?>" class="btn btn-success" >Back</a>
                                            <p class="help-block"></p>
                                        </div>
                              
                                
                                </div>
                                <!-- /.col-lg-6 (nested) -->                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

