<!DOCTYPE html>
<html>
<head>
	<title>Successsfull!!!</title>
</head>
<body>
Successfully Saved!!!

</br>
       <p><a href="<?php echo site_url('news/index/'); ?>">View all</a></p>

</body>
</html>