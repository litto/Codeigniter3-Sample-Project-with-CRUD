

<!-- footer -->
 <!-- jQuery -->
    <script src="<?php echo base_url();?>/js/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>/js/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>/js/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url();?>/js/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>/js/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>/js/dist/js/sb-admin-2.js"></script>

    <!-- Boot box js -->
    <script src="<?php echo base_url();?>/js/bower_components/bootstrap/dist/js/bootbox.min.js"></script>		

    <!--select search js -->
    <script src="<?php echo base_url();?>/js/select2.js"></script>		 

    <!--manage painters point js -->
    <script src="<?php echo base_url();?>/js/managepaintersPoints.js"></script>

    <!--manage painters point Deduction js -->
    <script src="<?php echo base_url();?>/js/managepainterPointDeduction.js"></script>	

    <!-- datepicker js -->
    <script src="<?php echo base_url();?>/js/bootstrap-datepicker.js"></script>
		
<script>

</script>

</body>

</html>