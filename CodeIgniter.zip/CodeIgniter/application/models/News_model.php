<?php
class News_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

public function get_news($slug = FALSE)
{
        if ($slug === FALSE)
        {
                $query = $this->db->get('news');
                return $query->result_array();
        }

        $query = $this->db->get_where('news', array('slug' => $slug));
        return $query->row_array();
}

    function count_items(){
        return $this->db->count_all('news');
    }


    function get_itemspaginate($limit, $offset){
        $data = array();
        $this->db->limit($limit, $offset);
        $Q = $this->db->get('news');
        if($Q->num_rows() > 0){
            foreach ($Q->result_array() as $row){
                $data[] = $row;
            }
        }
        $Q->free_result();
        return $data;
    }

public function get_newsid($id)
{

        $query = $this->db->get_where('news', array('id' => $id));
        return $query->row_array();
}

public function set_news()
{
    $this->load->helper('url');

    $slug = url_title($this->input->post('title'), 'dash', TRUE);

    $data = array(
        'title' => $this->input->post('title'),
        'slug' => $slug,
        'text' => $this->input->post('text')
    );

    return $this->db->insert('news', $data);
}

public function updatenews($list)
{
    $this->load->helper('url');

    $slug = url_title($list['title'], 'dash', TRUE);

    $data = array(
        'title' => $list['title'],
        'slug' => $slug,
        'text' => $list['content']
    );

                $this->db->where('id',$list['id']);
                   $this->db->update('news',$data); 
                   return 1;
}

public function updatenewsimage($list)
{
    $this->load->helper('url');

    $slug = url_title($list['title'], 'dash', TRUE);

    $data = array(
        'title' => $list['title'],
        'slug' => $slug,
        'text' => $list['content'],
         'image'=>$list['image']

    );

                $this->db->where('id',$list['id']);
                   $this->db->update('news',$data); 
                   return 1;
}

public function addnews($list)
{
    $this->load->helper('url');

    $slug = url_title($list['title'], 'dash', TRUE);

    $data = array(
        'title' => $list['title'],
        'slug' => $slug,
        'text' => $list['content'],
        'image'=>$list['imagename']
    );

     return $this->db->insert('news', $data);
}

public function deletenews($id)
{

	 $this->db->where('id',$id);
     $this->db->delete('news'); 
  

  }






}

?>