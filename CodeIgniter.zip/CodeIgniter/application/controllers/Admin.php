<?php
class Admin extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->model('admin_model');
                $this->load->helper('url_helper');
                $this->load->library('session');
        }



              public function index()
        {
      $data['msg']='';
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'News archive';

        $this->load->view('templates/loginheader', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/loginfooter');
        $save=$this->input->post('submit');
         if($save){
        $name=$this->input->post('email');
        $password=$this->input->post('password');

         $authdet = $this->admin_model->get_admin($name);

         if(count($authdet)>0){

         	if($authdet['password']==$password){
$_SESSION['adminusername'] =$authdet['username'];
$_SESSION['adminemail'] =$authdet['email'];

      redirect('admin/home',$data);    
      	}else{
         	$data['msg']=" Password errror!!";
         	$this->session->set_flashdata('msg', 'Password errror!!');
         	redirect('admin/index'); 
         	}

         }else{
         	  	$this->session->set_flashdata('msg', 'Login errror!!');
         	redirect('admin/index'); 
         }



         }	


        }


public function home(){
	    $data['title'] = 'News archive';


	    $this->load->view('templates/header', $data);
        $this->load->view('admin/home', $data);
        $this->load->view('templates/footer');



}


public function logout(){

unset($_SESSION['adminusername']);
unset($_SESSION['adminemail']);
redirect('admin/index',$data); 
}






    }    



    ?>