<?php
class News extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->model('news_model');
                $this->load->helper('url_helper');
        }

        public function index()
        {
      
  
        $data['title'] = 'News archive';
        $this->load->library('pagination');

        $this->load->helper('url');
$data['urls']=base_url();
        


        $result_per_page = 2;  // the number of result per page

       $config['base_url'] = $data['urls'].'index.php/news/page';// configuring url to which page is located
        $config['total_rows'] = $this->news_model->count_items();
        $config['per_page'] = $result_per_page;
        $this->pagination->initialize($config);

$this->pagination->initialize($config);// initializing the configs 
   
 $data['news'] = $this->news_model->get_itemspaginate($config['per_page'], $this->uri->segment(3));
$data['pagelinks']= $this->pagination->create_links();//creating links


        $this->load->view('templates/header', $data);
        $this->load->view('news/index', $data);
        $this->load->view('templates/footer');
        }

public function view($slug = NULL)
{
        $data['news_item'] = $this->news_model->get_news($slug);

        if (empty($data['news_item']))
        {
                show_404();
        }

        $data['title'] = $data['news_item']['title'];
        
        $this->load->view('templates/header', $data);
        $this->load->view('news/view', $data);
        $this->load->view('templates/footer');
}

public function edit($id){

  $this->load->helper('form');
    $this->load->library('form_validation');

    $data['title'] = 'Create a news item';

    $this->form_validation->set_rules('title', 'Title', 'required');
    $this->form_validation->set_rules('text', 'Text', 'required');
 $data['news_item'] = $this->news_model->get_newsid($id);

        $data['title'] = $data['news_item']['title'];

        $this->load->view('templates/header', $data);
        $this->load->view('news/edit', $data);
        $this->load->view('templates/footer');

        $save=$this->input->post('submit');
if($save){

           $title=$this->input->post('title');
        $text=$this->input->post('text');
        $newsid=$this->input->post('newsid');

        $config['upload_path'] = 'uploads/'; 
$config['allowed_types'] = 'gif|jpg|jpeg|png'; 
$config['max_size'] = '1000'; 
$config['max_width'] = '1920'; 
$config['max_height'] = '1280'; 

$this->load->library('upload', $config); 
if(!$this->upload->do_upload()) 
$this->upload->display_errors(); 
else { 
$fInfo = $this->upload->data(); //uploading
  $this->gallery_path = realpath(APPPATH . '../uploads');//fetching path

$config1 = array(
      'source_image' => $fInfo['full_path'], //get original image
      'new_image' => $this->gallery_path.'/thumbs', //save as new image //need to create thumbs first
      'maintain_ratio' => true,
      'width' => 150,
      'height' => 100
       
    );
    $this->load->library('image_lib', $config1); //load library
    $this->image_lib->resize(); //generating thumb
    $imagename=$fInfo['file_name'];// we will get image name here
$list=array('title'=>$title,'content'=>$text,'image'=>$imagename,'id'=>$newsid);//
$this->news_model->updatenewsimage($list);//pasing as array to the model

}

$list=array('title'=>$title,'content'=>$text,'id'=>$newsid);//
$this->news_model->updatenews($list);//pasing as array to the model
redirect('news/index',$data); 
}

}

public function create()
{
    $this->load->helper('form');
    $this->load->library('form_validation');

    $data['title'] = 'Create a news item';

    $this->form_validation->set_rules('title', 'Title', 'required');
    $this->form_validation->set_rules('text', 'Text', 'required');

    if ($this->form_validation->run() === FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('news/create');
        $this->load->view('templates/footer');

    }
    else
    {


$config['upload_path'] = 'uploads/'; 
$config['allowed_types'] = 'gif|jpg|jpeg|png'; 
$config['max_size'] = '1000'; 
$config['max_width'] = '1920'; 
$config['max_height'] = '1280'; 

$this->load->library('upload', $config); 
if(!$this->upload->do_upload()) 
$this->upload->display_errors(); 
else { 
$fInfo = $this->upload->data(); //uploading
  $this->gallery_path = realpath(APPPATH . '../uploads');//fetching path

$config1 = array(
      'source_image' => $fInfo['full_path'], //get original image
      'new_image' => $this->gallery_path.'/thumbs', //save as new image //need to create thumbs first
      'maintain_ratio' => true,
      'width' => 150,
      'height' => 100
       
    );
    $this->load->library('image_lib', $config1); //load library
    $this->image_lib->resize(); //generating thumb
}

$imagename=$fInfo['file_name'];// we will get image name here
$title=$this->input->post('title');
$text=$this->input->post('text');

$list=array('title'=>$title,'content'=>$text,'imagename'=>$imagename);//

        $this->news_model->addnews($list);
        $this->load->view('news/success');
    }
}

public function delete($id){

$this->news_model->deletenews($id);//pasing as array to the model
redirect('news/index',$data); 

     }   



}

?>