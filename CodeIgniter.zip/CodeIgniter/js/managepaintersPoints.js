var root = $('#rootValue').val();

$(document).ajaxStart(function(){
    $("#wait").css("display", "block");
});

$(document).ajaxComplete(function(){
    $("#wait").css("display", "none");
});

$(document).ajaxStart(function(){
    $("#wait1").css("display", "block");
});

$(document).ajaxComplete(function(){
    $("#wait1").css("display", "none");
});

var delay = (function(){
  var timer = 0;
  return function(callback, ms){
    clearTimeout (timer);
    timer = setTimeout(callback, ms);
  };
})();


/*Start Add Points Section  */
$('.AddPoint').click(function(){
var first_name= $(this).data('first_name');
$('#addpointsPainterName').html(first_name);

$('select#product').val('');
$('#quantity').val('');
$('select#dealer').val('');
$('#point').val('');
$('#MsgBox').html('');
$('#save').attr('disabled',false);

var painterid=$(this).data('id');
$('#save').click(function(){
var pr = $('select#product').val();
var qu = $('#quantity').val();
var d  = $('#dealer').val();
var flag  = 0;
if(pr == ''){
$("#productDiv").addClass("has-error");
flag = 1;
}else{
$("#productDiv").removeClass("has-error");
}
if(qu == ''){
$("#quantityDiv").addClass("has-error");
flag = 1;
}else{
$("#quantityDiv").removeClass("has-error");
}
if(d == ''){
$("#dealerDiv").addClass("has-error");
flag = 1;
}else{
$("#dealerDiv").removeClass("has-error");
}

if(flag == 0){
$("#productDiv").removeClass("has-error");
$("#quantityDiv").removeClass("has-error");
$("#dealerDiv").removeClass("has-error");

//ajax code here to save points of painter
$.ajax({
global: false,
type:"GET",
data:{painterid:painterid,pr:pr,qu:qu,d:d},
//url:'addPainterPoint.php'
url:root + 'admin/ajax/addPainterPoint'
}).done(function(data){
var newdata=JSON.parse(data);
$('#MsgBox').html(newdata[1]);
//$('td#TotPoint'+painterid+'').html(newdata[0]);
$('#save').attr('disabled',true);
return false;
});
return false;
}else{
return false;
}
});


})

//quantity validation & point calculation
$("#quantity").keyup(function(){
delay(function(){      
$("#quantityDiv").removeClass("has-error");  
var val = $('#quantity').val();
var pr = $('select#product').val();
var d  = $('select#dealer').val();
if(d==''){
$("#dealerDiv").addClass("has-error");
}else{
$("#dealerDiv").removeClass("has-error");
}
if(pr != ''){
//ajax code to show total point
$.ajax({
type:"GET",
data:{pr:pr,q:val},
//url:'viewTotalPoint.php'
url:root + 'admin/ajax/viewTotalPoint'
}).done(function(data){
$('#point').val(data);
});
return false;
}else{
$("#productDiv").addClass("has-error");
return false;
}
return false;
}, 300 );
});

//product validation & point calculation
function removeErrorclass(val){
if(val==''){
$("#productDiv").addClass("has-error");
}else{
$("#productDiv").removeClass("has-error");
var q = $('#quantity').val();
var d = $('select#dealer').val();
if(d == ''){
$("#dealerDiv").addClass("has-error");
}else{
$("#dealerDiv").removeClass("has-error");
}
//var pr = $('select#product').val();
if(q != ''){
//ajax code to show total point
$.ajax({
type:"GET",
data:{pr:val,q:q},
url:root + 'admin/ajax/viewTotalPoint'
}).done(function(data){
$('#point').val(data);
});
return false;
}else{
$("#quantityDiv").addClass("has-error");
return false;
}
}
}


function removeDealerErrorclass(val){
if(val==''){
$("#dealerDiv").addClass("has-error");
}else{
$("#dealerDiv").removeClass("has-error");
var q = $('#quantity').val();
var pr = $('select#product').val();

if(q == ''){
$("#quantityDiv").addClass("has-error");
}else{
$("#quantityDiv").removeClass("has-error");
}

if(pr == ''){
$("#productDiv").addClass("has-error");
}else{
$("#productDiv").removeClass("has-error");
}

if(q != '' && pr != ''){

//ajax code to show total point
$.ajax({
type:"GET",
data:{pr:pr,q:q},
//url:'viewTotalPoint.php'
url:root + 'admin/ajax/viewTotalPoint'
}).done(function(data){
$('#point').val(data);
});
$("#quantityDiv").removeClass("has-error");
$("#productDiv").removeClass("has-error");
return false;
}else{
$("#quantityDiv").addClass("has-error");
$("#productDiv").addClass("has-error");
return false;
}

}
}

/* End Add Points Section */



/*
show painter's profile
*/

$('.painterprofile').click(function(){
var painterid=$(this).data('id');
if(painterid != ''){
$.ajax({
method:'get',
data:{painterid:painterid},
url:'getPainterProfile.php'
}).done(function(data){

var newdata=JSON.parse(data);
$('#paintername').val(newdata.painter.Name);
$('#painteraddress').val(newdata.painter.Address);
$('#painterphone').val(newdata.painter.Phone);
$('#painterstate').val(newdata.painter.StateName);
$('#painterregion').val(newdata.painter.RegionName);
$('#painterdistrict').val(newdata.painter.DistrictName);
$('#painterdealer').val(newdata.painter.DealerName);
$('#painterexecutive').val(newdata.painter.ExecutiveName);
$('#paintertotal').val(newdata.painter.TotalPoints);
$('#paintergift').val(newdata.gift.Gifts);
});
}

});
/* 
end painter profile
*/

