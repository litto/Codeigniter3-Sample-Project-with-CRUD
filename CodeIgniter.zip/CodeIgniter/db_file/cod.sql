-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2016 at 11:21 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cod`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_admin`
--

CREATE TABLE IF NOT EXISTS `cms_admin` (
  `auth_id` int(120) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `date_login` datetime NOT NULL,
  `login_ip` varchar(500) NOT NULL,
  `status` int(120) NOT NULL,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cms_admin`
--

INSERT INTO `cms_admin` (`auth_id`, `username`, `password`, `email`, `date_login`, `login_ip`, `status`) VALUES
(1, 'admin', 'admin', 'info@penieltech.com', '2016-10-04 08:27:20', '::1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_userauth`
--

CREATE TABLE IF NOT EXISTS `cms_userauth` (
  `user_id` int(120) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `photo` varchar(500) NOT NULL,
  `status` int(120) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cms_userauth`
--

INSERT INTO `cms_userauth` (`user_id`, `name`, `email`, `photo`, `status`) VALUES
(1, 'John Abraham', 'litto@gmail.com', 'user-8d1de745147556606442833899210609282.png', 1),
(4, 'Litto', 'litto@penieltech.com', 'user-1006ff12147550289313754460210891103.png', 1),
(6, 'Ricky Martin', 'info@ricky.com', 'user-668f3321147556806387926764210196947.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `text` text NOT NULL,
  `image` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `text`, `image`) VALUES
(2, 'Bill or Purchase Invoice Format Customization in Quickbooks. Call- +971509617708', 'bill-or-purchase-invoice-format-customization-in-quickbooks-call-971509617708', '  rtttttttttttt', '33-512.png'),
(3, 'Sage 50 Basic Tutorial-Peniel technology LLC UAE. Call- +971509617708.mp4', 'sage-50-basic-tutorial-peniel-technology-llc-uae-call-971509617708mp4', '  ssssssssssssss', 'Lock_secure_security_password.png'),
(4, 'Tally Dealers in UAE', 'tally-dealers-in-uae', ' ssddd', 'Voucher_3D-512.png'),
(7, 'Quickbooks Basic Tutorial-Peniel technology LLC UAE. Call- +971509617708', 'quickbooks-basic-tutorial-peniel-technology-llc-uae-call-971509617708', ' aaaaaaaaaaaaaaaa', 'Data-Template-icon.png'),
(8, 'New Item', 'new-item', 'gggggggggg', 'logout.png');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `body` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created`, `modified`) VALUES
(1, 'The title', 'This is the post body.', '2016-09-17 12:01:59', NULL),
(2, 'A title once again', 'And the post body follows.', '2016-09-17 12:01:59', NULL),
(3, 'Title strikes back', 'This is really exciting! Not.', '2016-09-17 12:02:00', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
